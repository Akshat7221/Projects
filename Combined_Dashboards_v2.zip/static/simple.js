
async function loadSimple(use='sample'){
  const res = await fetch('/api/applicants/simple?use='+use);
  const data = await res.json();
  const k = data.kpis;
  document.getElementById('s_total').innerText = k.total_applicants;
  document.getElementById('s_cgpa').innerText = k.avg_cgpa || 'N/A';
  document.getElementById('s_exp').innerText = k.avg_experience || 'N/A';
  document.getElementById('s_status').innerText = JSON.stringify(k.status_counts);
  // branch chart
  const branches = Object.keys(k.branch_counts || {});
  const vals = Object.values(k.branch_counts || {});
  const ctx = document.getElementById('s_branch_chart').getContext('2d');
  if(window.sb) window.sb.destroy();
  window.sb = new Chart(ctx, {type:'bar', data:{labels:branches, datasets:[{label:'Applicants', data:vals, backgroundColor:'#6ecbff'}]}, options:{indexAxis:'x'}});
}
document.getElementById('up_s').addEventListener('click', async ()=>{
  const fi = document.getElementById('file_s');
  if(!fi.files.length){ alert('Choose file'); return; }
  const fd = new FormData(); fd.append('file', fi.files[0]);
  const res = await fetch('/api/upload/applicants', {method:'POST', body:fd});
  const j = await res.json();
  document.getElementById('msg_s').innerText = j.message || j.status || JSON.stringify(j);
  if(j.status==='ok') loadSimple('upload');
});
loadSimple();
