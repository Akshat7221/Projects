
async function loadAdvanced(use='sample'){
  const res = await fetch('/api/applicants/advanced?use='+use);
  const data = await res.json();
  document.getElementById('a_total').innerText = data.total_applicants;
  document.getElementById('a_back').innerText = data.backlog_yes_count;
  document.getElementById('a_cgpa').innerText = (data.get('graduation_percentages') && data.graduation_percentages.length>0) ? (Math.round((data.graduation_percentages.reduce((a,b)=>a+b,0)/data.graduation_percentages.length)*100)/100) : 'N/A';
  // gender pie
  const g_labels = Object.keys(data.gender_counts || {});
  const g_vals = Object.values(data.gender_counts || {});
  const ctx = document.getElementById('gender_chart').getContext('2d');
  if(window.gch) window.gch.destroy();
  window.gch = new Chart(ctx, {type:'pie', data:{labels:g_labels, datasets:[{data:g_vals, backgroundColor:['#6ecbff','#8b6bff','#4dd0e1']}]}});

  // course horizontal bar
  const c_labels = Object.keys(data.course_counts || {});
  const c_vals = Object.values(data.course_counts || {});
  const ctx2 = document.getElementById('course_chart').getContext('2d');
  if(window.cch) window.cch.destroy();
  window.cch = new Chart(ctx2, {type:'bar', data:{labels:c_labels, datasets:[{data:c_vals, backgroundColor:'#6ecbff'}]}, options:{indexAxis:'y'} });

  // specialization word cloud (simple scaling)
  const wc = document.getElementById('wordcloud');
  wc.innerHTML = '';
  const specs = data.specialization_freq || {};
  const maxv = Math.max(...Object.values(specs||{1:1}));
  for(const [word, count] of Object.entries(specs)){
    const size = 12 + (count/maxv)*36;
    const span = document.createElement('span');
    span.style.fontSize = size + 'px';
    span.style.margin = '6px';
    span.style.display = 'inline-block';
    span.textContent = word + ' ('+count+')';
    wc.appendChild(span);
  }

  // graduation histogram
  const grads = data.graduation_percentages || [];
  const ctx3 = document.getElementById('grad_hist').getContext('2d');
  if(window.gh) window.gh.destroy();
  // build histogram buckets
  const buckets = Array.from({length:10},()=>0);
  grads.forEach(v=>{ const idx = Math.min(9, Math.floor(v/10)); buckets[idx]++; });
  const labels = buckets.map((_,i)=> (i*10)+'-'+(i*10+9));
  window.gh = new Chart(ctx3, {type:'bar', data:{labels:labels, datasets:[{label:'Graduation % distribution', data:buckets, backgroundColor:'#8b6bff'}]}, options:{responsive:true}});

  // sample table
  const table = data.sample_table || [];
  const area = document.getElementById('sample_table');
  if(!table.length){ area.innerText='No sample rows'; } else {
    let html = '<table><thead><tr>';
    const keys = Object.keys(table[0]);
    keys.forEach(k=> html += '<th>'+k+'</th>');
    html += '</tr></thead><tbody>';
    table.forEach(r=>{ html += '<tr>'; keys.forEach(k=> html += '<td>'+(r[k]===null?'':r[k])+'</td>'); html += '</tr>'; });
    html += '</tbody></table>';
    area.innerHTML = html;
  }
}

document.getElementById('up_a').addEventListener('click', async ()=>{
  const fi = document.getElementById('file_a'); if(!fi.files.length){ alert('Choose file'); return; }
  const fd = new FormData(); fd.append('file', fi.files[0]);
  const res = await fetch('/api/upload/applicants',{method:'POST', body:fd});
  const j = await res.json();
  document.getElementById('msg_a').innerText = j.message || j.status || JSON.stringify(j);
  if(j.status==='ok') loadAdvanced('upload');
});

loadAdvanced();
